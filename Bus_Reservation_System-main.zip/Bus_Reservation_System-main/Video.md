## Video
The link corresponds to a video of a walkthrough of our project along with its demonstration.
[Click here](https://drive.google.com/drive/u/0/folders/1GuylnJ2z6mpFCiJ34-pzH-eAF26q_KNz) to access the video.
